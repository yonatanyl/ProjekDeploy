<script src="<?= base_url("assets/js/sidebarmenu.js") ?>"></script>
<script src="<?= base_url("assets/js/app.min.js") ?>"></script>
<script src="<?= base_url("assets/libs/simplebar/simplebar.js") ?>"></script>