<script src="<?= base_url("assets/libs/jquery/jquery.min.js") ?>"></script>
<script src="<?= base_url("assets/libs/bootstrap/js/bootstrap.bundle.min.js") ?>"></script>