<div class="py-6 px-6 text-center">
  <p class="mb-0 fs-4">&copy; 2024, made with ❤️ by <a href="" target="_blank" class="pe-1 text-primary text-decoration-underline">Samsan Tech</a></p>
</div>